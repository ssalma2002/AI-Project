    if len(sys.argv) != 2:
        print("Usage: python tictactoe.py [minimax | alpha-beta]")
        sys.exit(1)

    algorithm_choice = sys.argv[1].lower()

    if algorithm_choice not in ["minimax", "alpha-beta"]:
        print("Invalid algorithm choice. Use 'minimax' or 'alpha-beta'.")
        sys.exit(1)

    
    if algorithm_choice == "minimax":
        game = Game(1)
        
    else: #alphabeta
        game = Game(2)
        
        
    board = game.board
    ai = game.ai
    ai.print_algorithm()