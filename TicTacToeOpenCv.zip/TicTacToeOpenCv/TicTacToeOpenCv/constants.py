width =600
height = 600

rows =3
cols= 3

sq_Size = width/cols

line_width =15
circle_width =15
cross_width =20

radius= sq_Size / 4

offset =50
#colors
bg_color =(28,170,156)
line_color=(23,145,135)
circle_color =(239,231,200)
cross_color =(66,66,66)

